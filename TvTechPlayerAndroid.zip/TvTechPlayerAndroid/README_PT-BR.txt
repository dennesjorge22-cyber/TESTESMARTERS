TvTech Player — projeto Android inicial

O QUE É
Este projeto empacota o painel HTML fornecido em um aplicativo Android usando WebView.
Inclui permissão de internet e seletor de arquivo para importar listas M3U locais.

COMO ABRIR E COMPILAR
1. Instale o Android Studio e o Android SDK (API 35).
2. Extraia o ZIP para uma pasta no computador.
3. No Android Studio, escolha Open e selecione a pasta TvTechPlayerAndroid.
4. Aguarde a sincronização do Gradle. Se solicitado, instale os componentes do SDK.
5. Para testar, conecte um aparelho Android com depuração USB ativada ou use um emulador.
6. No menu Build, escolha Build APK(s).
7. O APK de depuração normalmente fica em app/build/outputs/apk/debug/app-debug.apk.

IMPORTANTE
- O projeto é uma base inicial; não foi possível executar uma compilação Android neste ambiente.
- O painel HTML foi adaptado com o título e a marca TvTech Player, mas a interface interna ainda precisa de revisão visual.
- O HTML original depende de Hls.js e de serviços externos de proxy CORS como alternativa. Esses serviços podem falhar, ter limites ou expor a URL solicitada a terceiros. Prefira URLs M3U fornecidas por fontes confiáveis e autorizadas.
- Alguns streams HTTP/HTTPS, codecs, formatos e provedores podem não funcionar no WebView. Compatibilidade deve ser testada no aparelho real.
- A opção de importar arquivo M3U usa o seletor de arquivos do Android.
- Antes de distribuir publicamente, revise segurança, privacidade, licenças e direitos de distribuição dos conteúdos.
- Nunca compartilhe credenciais privadas da sua lista M3U.
